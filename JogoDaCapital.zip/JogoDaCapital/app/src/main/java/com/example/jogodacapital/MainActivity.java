package com.example.jogodacapital;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Random;
import java.util.Set;

public class MainActivity extends AppCompatActivity {

    TextView estadoView, resultadoView, scoreView;
    EditText input;
    Button button;
    Random rand = new Random();
    int qtdBotaoPressionado = 0, qtdJogos = 0;
    int countDaArray = 0, score = 0;
    int estadosRandomizados[] = new int[6];

    String[][] estados = {
            {"Acre", "Rio Branco"},
            {"Alagoas", "Maceio"},
            {"Paraíba", "Joao Pessoa"},
            {"Sergipe", "Aracaju"},
            {"Mato Grosso", "Cuiaba"},
            {"Maranhão", "Sao Luis"},
            {"Amapá", "Macapa"},
            {"Piauí", "Teresina"},
            {"Rondônia", "Porto Velho"},
            {"Roraima", "Boa Vista"},
            {"Tocantins", "Palmas"},
            {"Mato Grosso do Sul", "Campo Grande"},
            {"Goiás", "Goiania"},
            {"Espírito Santo", "Vitoria"},
            {"Paraná", "Curitiba"}};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        estadoView = findViewById(R.id.textViewEstado);
        resultadoView = findViewById(R.id.textViewResultado);
        scoreView = findViewById(R.id.textViewScore);
        button = findViewById(R.id.button);
        input = findViewById(R.id.editTextInput);

        primeiraVezIniciado();

        input.getBackground().setColorFilter(Color.BLACK, PorterDuff.Mode.SRC_IN); //não sei pq ele começa esverdeado (talvez pq ele copia o parente?), mudando pra preto aqui.
    }

    public void primeiraVezIniciado () {
        randomizaEstadosSemRepeticao();
        estadoView.setText(estados[estadosRandomizados[countDaArray]][0]);
        scoreView.setText("SCORE: " + score);
    }

    public void confereCapital(View view) {
        if (qtdJogos < 5) {
            if (qtdBotaoPressionado == 0) {
                if (input.getText().toString().equalsIgnoreCase(estados[estadosRandomizados[countDaArray]][1])) {
                    acertou();
                }else{
                    if (input.length() == 0) {
                        Toast msg = Toast.makeText(this, "Digite algo!", Toast.LENGTH_SHORT);
                        msg.show();
                    }else{
                        errou();
                    }
                }
            }else{
                reniciaTelaAposAcerto();
            }
        }else{
            fimDeJogo();
            qtdBotaoPressionado++;
        }
        if(qtdJogos == 7){
            recomecouJogo();
        }
    }

    public void acertou(){
        input.setEnabled(false);
        resultadoView.setText("ACERTOU");
        button.setText("PROXIMO");
        score += 10;
        countDaArray++;
        scoreView.setText("SCORE: " + score);
        qtdJogos++;
        qtdBotaoPressionado++;
    }

    public void errou(){
        resultadoView.setText("ERROU! Correto: " + estados[estadosRandomizados[countDaArray]][1]);
        input.setEnabled(false);
        button.setText("PROXIMO");
        countDaArray++;
        qtdJogos++;
        qtdBotaoPressionado++;
    }

    public void reniciaTelaAposAcerto(){
        estadoView.setText(estados[estadosRandomizados[countDaArray]][0]);
        input.setText("");
        button.setText("CONFERIR");
        resultadoView.setText("");
        input.setEnabled(true);
        qtdBotaoPressionado = 0;
    }

    public void fimDeJogo (){
        scoreView.setText("");
        button.setText("REINICIAR");
        resultadoView.setText("");
        input.setEnabled(false);
        input.getBackground().setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_IN);
        estadoView.setText("PARABÉNS");
        input.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        input.setText("SCORE: " + score);
        randomizaEstadosSemRepeticao();
        qtdJogos++;
    }

    public void recomecouJogo(){
            input.setEnabled(true);
            input.getBackground().setColorFilter(Color.BLACK, PorterDuff.Mode.SRC_IN);
            input.setHint("Capital");
            input.setTextAlignment(View.TEXT_ALIGNMENT_INHERIT);
            qtdJogos = 0;
            countDaArray = 0;
            reniciaTelaAposAcerto();
    }

    public void randomizaEstadosSemRepeticao() {

        for (int i = 0; i < estadosRandomizados.length; i++){
            estadosRandomizados[i] = -1;
        }

        estadosRandomizados[0] = rand.nextInt(14);

        for (int novoNumero = 1; novoNumero < estadosRandomizados.length; ++novoNumero){
            estadosRandomizados[novoNumero] = rand.nextInt(14);

            for (int veriNume = 0; veriNume < novoNumero; ++veriNume){
                if ( estadosRandomizados[veriNume] == estadosRandomizados[novoNumero]){
                    estadosRandomizados[novoNumero] = rand.nextInt(14);
                    veriNume = 0;
                }
            }
        }
    }

}